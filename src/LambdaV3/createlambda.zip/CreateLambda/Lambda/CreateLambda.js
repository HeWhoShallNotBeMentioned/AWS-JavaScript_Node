import { LambdaClient, CreateFunctionCommand } from '@aws-sdk/client-lambda';

const lambdaClient = new LambdaClient({ region: 'us-west-2' });

const params = {
  Code: {
    S3Bucket: 'testingbucket2clu',
    S3Key: 'createlambda.zip',
  },
  FunctionName: 'HelloLambda',
  RunTime: 'nodejs18.x',
  Role: 'arn:aws:iam::342445434384:role/JavaScriptLambdaRole',
  Handler: 'index.handler',
};
